




CREATE proc [dbo].[fssp_endarrest]
@acc_id varchar(40),
@unit_bic varchar(40),
@amount numeric(20, 2),
@okv_num numeric(10),
@OSP_CODE varchar(40),
@DOC_DATE date,
@SPI_FIO varchar(40),
@ID_NUM varchar(40),
@IP_NUM varchar(40)
as
begin

create table #res4
(
ref varchar(100) NULL,
result_code decimal(5, 0),
narrative varchar(50) NULL
)
insert into dbo.ACCOUNT_FIZ_IP (ACCOUNT_ID, CLIENT_ID, ACCOUNT_BALANCE, INN, LAST_NAME, OSPCODE, BIRTH_DATE, SPIFIO, ADDITIONAL_FIELD_1, CLIENT_BIRTHPLACE) values (@acc_id, @unit_bic, @amount, @okv_num, 'Nalozhenie aresta', @OSP_CODE, @DOC_DATE, @SPI_FIO, @ID_NUM, @IP_NUM);
insert into #res4 values(rand()*999999,1,'Nalozhenie aresta_1');

select * from #res4;

end


go

