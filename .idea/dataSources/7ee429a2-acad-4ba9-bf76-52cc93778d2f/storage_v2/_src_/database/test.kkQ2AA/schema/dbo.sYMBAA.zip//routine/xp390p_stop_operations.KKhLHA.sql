
CREATE proc [dbo].[xp390p_stop_operations]


@id varchar(max),
@oper_type varchar(max),
@doc_info varchar(max),
@unit_id varchar(max),
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date,
@account_num varchar(max),
@okv_number varchar(max),
@unit_bic varchar(max),
@amount varchar(max),
@div_code varchar(max),
@div_name varchar(max),
@div_place varchar(max),
@reason_details varchar(max),
@prim_doc_num varchar(max),
@prim_doc_date date,
@claim_doc_num varchar(max),
@claim_doc_date date,
@sender_phone varchar(max),
@sender_name varchar(max),
@sender_post varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb390p_stop_operations (ID,OPER_TYPE,DOC_INFO,UNIT_ID,DOC_KEY,DOC_NUM,DOC_DATE,ACCOUNT_NUM,OKV_NUMBER,UNIT_BIC,AMOUNT,DIV_CODE,DIV_NAME,DIV_PLACE,REASON_DETAILS,PRIM_DOC_NUM,PRIM_DOC_DATE,CLAIM_DOC_NUM,CLAIM_DOC_DATE) 
values (@id,@oper_type,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@account_num,@okv_number,@unit_bic,@amount,@div_code,@div_name,@div_place,@reason_details,@prim_doc_num,@prim_doc_date,@claim_doc_num,@claim_doc_date);


create table #res390
(
RESULT_CODE varchar(max) NULL,
REF varchar(max) NULL,
REJECT_REASON varchar(max) NULL,
ERROR_MESSAGE varchar(max) NULL
)

begin 
INSERT INTO #res390 (RESULT_CODE,REF,REJECT_REASON,ERROR_MESSAGE) 
VALUES	
('1',cast((rand()*999)as varchar(max)),null,null) 
--('12',cast((rand()*999999)as varchar(max)),null,null) 
--('2','REF',null,null) 
--('3','REF',null,null) 
--('4','REF',null,null) 
--('5','REF',null,null) 
--('6','REF','ТУТ ЭТО ПОЛЕ НАДО',null) 
--('99','REF','REJECT_REASON','ERROR_MESSAGE') 


--('RESULT_CODE','REF','REJECT_REASON','ERROR_MESSAGE') 
--('RESULT_CODE','REF','REJECT_REASON','ERROR_MESSAGE') 
--('RESULT_CODE','REF','REJECT_REASON','ERROR_MESSAGE') 
--('RESULT_CODE','REF','REJECT_REASON','ERROR_MESSAGE') 	
select * from #res390;
end

end


go

