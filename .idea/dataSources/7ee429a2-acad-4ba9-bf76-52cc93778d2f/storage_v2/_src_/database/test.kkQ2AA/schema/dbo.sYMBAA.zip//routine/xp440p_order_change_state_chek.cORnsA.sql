

CREATE proc [dbo].[xp440p_order_change_state_chek]
@ref varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_order_change_state_chek (ref) 
values (@ref);

create table #res440
(
RESULT_CODE varchar(max) null,
REF varchar(max) null,
REJECT_REASON varchar(max) null,
ERROR_MESSAGE varchar(max) null
)


INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERROR_MESSAGE) 

VALUES				('12','12345',null,null);
  --VALUES				('6',null,'REJECT_REASON, Опционально, если Код типа ответа = 6',null);
  --VALUES				('99',null,null,'ERROR_MESSAGE, Обязательно, если Код результата операции  = 99');          	
 
select * from #res440;

end


go

