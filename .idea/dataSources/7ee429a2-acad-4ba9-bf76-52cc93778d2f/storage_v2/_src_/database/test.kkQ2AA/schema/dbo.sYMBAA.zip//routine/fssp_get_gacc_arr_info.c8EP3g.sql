



CREATE proc [dbo].[fssp_get_gacc_arr_info]
@client_id varchar(40)
as
begin
/**Выборка сведений о наложенных обременениях из таблицы dbo.ENCUMBRANCE для передачи в Систему**/
select ACT_DATE,ACCOUNT_ID,UNIT_BIC,AMOUNT,ENCUMBRANCE_DATE,ENCUMBRANCE_ID from dbo.ENCUMBRANCE where CLIENT_ID = @client_id;


/**
create table #res5
(
date_actual smalldatetime NULL,
account varchar(50) NULL,
bic varchar(20) NULL,
amount numeric(20, 2) NULL,
enc_date date NULL,
enc_num varchar(20) NULL
)
insert into dbo.ACCOUNT_FIZ_IP (CLIENT_ID, LAST_NAME) values (@client_id, 'Poisk sved o arestah i obrem');
insert into #res5 values(GETDATE(), '40817810701000009021', '041012765', 10.00, '2015-02-01', '54340');
--insert into #res5 values(GETDATE(), '40817810701000001021', '041012765', 10.00, '2015-02-01', '54341');
--insert into #res5 values(GETDATE(), '40817810701000001021', '041012765', 5.00, '2015-02-01', '54342');
--insert into #res5 values(GETDATE(), '40817810701000001021', '041012765', 5.00, '2015-02-01', '54343');
--insert into #res5 values(GETDATE(), '40817810701000001025', '041012765', 200.00, '2015-02-01', '324250');
--insert into #res5 values(GETDATE(), '40817810701000001025', '041012765', 400.00, '2015-02-01', '324251');
--insert into #res5 values(GETDATE(), '40817810701000001025', '041012765', 5000.00, '2015-02-01', '324241');
--insert into #res5 values(GETDATE(), '40817810701000001022', '041012765', 1200.00, '2015-02-01', '324233');
select * from #res5; **/
end


go

