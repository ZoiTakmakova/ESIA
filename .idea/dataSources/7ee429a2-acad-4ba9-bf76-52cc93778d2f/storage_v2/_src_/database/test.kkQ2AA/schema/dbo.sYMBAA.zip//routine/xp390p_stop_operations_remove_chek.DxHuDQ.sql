


CREATE proc [dbo].[xp390p_stop_operations_remove_chek]


@ref varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb390p_stop_operations_remove_chek (REF) 
values (@ref);


create table #res390
(
RESULT_CODE varchar(max) NULL,
REJECT_REASON varchar(max) NULL,
ERROR_MESSAGE varchar(max) NULL
)

begin 
INSERT INTO #res390 (RESULT_CODE,REJECT_REASON,ERROR_MESSAGE) 
VALUES	
('12',cast((rand()*999999)as varchar(max)),null) 
--('2','REF',null) 
--('3','REF',null) 
--('4','REF',null) 
--('5','REF',null) 
--('6','ТУТ ЭТО ПОЛЕ НАДО',null) 
--('99',REJECT_REASON','ERROR_MESSAGE') 
	
select * from #res390;
end

end


go

