
CREATE proc [dbo].[xp440p_identify]
@id varchar(max),
@doc_info varchar(max),
@unit_id varchar(max), 
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date, 
@query_type varchar(max), 
@query_kind varchar(max),
@query_from date,
@query_to date,
@query_date date,
@client_type int,
@last_name varchar(max),
@first_name varchar(max),
@patronymic_name varchar(max),
@name varchar(max),
@birth_date date,
@birth_place varchar(max),
@dul_type_id varchar(max),
@dul_ser varchar(max),
@dul_num varchar(max),
@dul_issue_date date,
@inn varchar(max),
@kpp varchar(max),
@postal_code varchar(max),
@region_code varchar(max),
@district varchar(max),
@city varchar(max),
@locality varchar(max),
@street varchar(max),
@house varchar(max),
@building varchar(max),
@apartment varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_identify (ID,DOC_INFO,UNIT_ID,DOC_KEY, DOC_NUM, DOC_DATE,QUERY_TYPE,QUERY_KIND,QUERY_FROM,QUERY_TO,QUERY_DATE,CLIENT_TYPE,LAST_NAME,FIRST_NAME,PATRONYMIC_NAME,NAME,BIRTH_DATE,BIRTH_PLACE,DUL_TYPE_ID,DUL_SER,DUL_NUM,DUL_ISSUE_DATE,INN,KPP,POSTAL_CODE,REGION_CODE,DISTRICT,CITY,LOCALITY,STREET,HOUSE,BUILDING,APARTMENT) 
values (@id,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@query_type,@query_kind,@query_from,@query_to,@query_date,@client_type,@last_name,@first_name,@patronymic_name,@name,@birth_date,@birth_place,@dul_type_id,@dul_ser,@dul_num,@dul_issue_date,@inn,@kpp,@postal_code,@region_code,@district,@city,@locality,@street,@house,@building,@apartment);

create table #res440
(
RESULT_CODE varchar(max) NULL,
CLIENT_ID varchar(max) NULL,
SYSTEM_ID varchar(max) NULL,
NAME varchar(max) NULL,
INN varchar(max) NULL,
KPP varchar(max) NULL,
LAST_NAME varchar(max) NULL,
FIRST_NAME varchar(max) NULL,
PATRONYMIC_NAME varchar(max) NULL,
ERRORS_MESSAGE varchar(max) NULL
)

/*
INSERT INTO #res440 (RESULT_CODE, CLIENT_ID, SYSTEM_ID, NAME, INN, KPP, LAST_NAME, FIRST_NAME, PATRONYMIC_NAME, ERRORS_MESSAGE) 
VALUES	
('1', @id ,'440P',@name,@inn,@kpp,'Фамилие','Име','Отчство',null);	--1 –Клиент найден
--('1', @id ,'440P',@name,@inn,@kpp,@last_name,@first_name,@patronymic_name,null);	--1 –Клиент найден
--('4', null ,null,null,null,null,null,null,null,null);								-- 4 – Клиент не найден		
--('99', null ,null,null,null,null,null,null,null,'Ошибка. _99_');				        --99 – Ошибка выполнения
--('3', @id ,'440P',@name,@inn,@kpp,@last_name,@first_name,@patronymic_name,null);	--3 – Однозначная идентификация клиента невозможна               	
--('1', @id ,'440P',null,@inn,null,null,null,null,null); --без обязательных полей
--INSERT INTO #res440 (RESULT_CODE, CLIENT_ID, SYSTEM_ID, NAME, INN, KPP, LAST_NAME, FIRST_NAME, PATRONYMIC_NAME, ERRORS_MESSAGE) 
--VALUES	
--('1', @id ,'440P',@name,@inn,@kpp,@last_name,@first_name,@patronymic_name,null); --1 –Клиент найден
--('4', null ,null,null,null,null,null,null,null,null);	-- 4 – Клиент не найден		
select * from #res440;
*/


IF @client_type = '1' --ЮЛ
begin 
INSERT INTO #res440 (RESULT_CODE, CLIENT_ID, SYSTEM_ID, NAME, INN, KPP, LAST_NAME, FIRST_NAME, PATRONYMIC_NAME, ERRORS_MESSAGE) 
VALUES	
--('1', @id ,'440P',@name,@inn,@kpp,null,null,null,null);	--1 –Клиент найден
('3', @id ,'440P',@name,@inn,@kpp,null,null,null,null);		--3 – Однозначная идентификация клиента невозможна 
--('4', null ,null,null,null,null,null,null,null,null);			-- 4 – Клиент не найден		
--('99', null ,null,null,null,null,null,null,null,'Ошибка. _99_');				    --99 – Ошибка выполнения
select * from #res440;
end

IF @client_type = '2' --ФЛ
begin 
INSERT INTO #res440 (RESULT_CODE, CLIENT_ID, SYSTEM_ID, NAME, INN, KPP, LAST_NAME, FIRST_NAME, PATRONYMIC_NAME, ERRORS_MESSAGE) 
VALUES	
--('1', @id ,'440P',null,null,null,@last_name,@first_name,@patronymic_name,null);	--1 –Клиент найден
('3', @id ,'440P',null,@inn,null,@last_name,@first_name,@patronymic_name,null);	--3 – Однозначная идентификация клиента невозможна 
--('4', null ,null,null,null,null,null,null,null,null);			-- 4 – Клиент не найден		
--('99', null ,null,null,null,null,null,null,null,'Ошибка. _99_');				    --99 – Ошибка выполнения
select * from #res440;
end

IF @client_type = '3' --ИП
begin 
INSERT INTO #res440 (RESULT_CODE, CLIENT_ID, SYSTEM_ID, NAME, INN, KPP, LAST_NAME, FIRST_NAME, PATRONYMIC_NAME, ERRORS_MESSAGE) 
VALUES	
--('1', @id ,'440P',null,@inn,null,@last_name,@first_name,@patronymic_name,null);	--1 –Клиент найден
('1', @id ,'440P',null,@inn,null,'last_name','first_name','patronymic_name',null);
--('3', @id ,'440P',null,@inn,null,@last_name,@first_name,@patronymic_name,null);	--3 – Однозначная идентификация клиента невозможна 
--('4', null ,null,null,null,null,null,null,null,null);			-- 4 – Клиент не найден		
--('99', null ,null,null,null,null,null,null,null,'Ошибка. _99_');				    --99 – Ошибка выполнения
select * from #res440;
end

end

go

