


CREATE proc [dbo].[xp440p_order_change_state]
@id varchar(max),
@oper_type varchar(max),
@doc_info varchar(max),
@unit_id varchar(max),  
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date, 
@src_doc_num varchar(max),
@src_doc_date date,
@account_num varchar(max),
@unit_bic varchar(max),
@ref varchar(max),
@div_code varchar(max),
@div_name varchar(max),
@amount varchar(max)

as
begin
/*
insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_order_change_state (id,oper_type,doc_info,unit_id,doc_key,doc_num,doc_date,src_doc_num,src_doc_date,account_num,unit_bic,ref) 
values (@id,@oper_type,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@src_doc_num,@src_doc_date,@account_num,@unit_bic,@ref);
*/
create table #res440
(
RESULT_CODE numeric(2),
REF varchar(max) NULL,
REJECT_REASON varchar(max) NULL,
ERRORS_MESSAGE varchar(max) null
)


INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERRORS_MESSAGE) 
VALUES				(1,cast((rand()*999999)as varchar(max)),'Нужно изменить',null);
                      	
 
select * from #res440;

end


go

