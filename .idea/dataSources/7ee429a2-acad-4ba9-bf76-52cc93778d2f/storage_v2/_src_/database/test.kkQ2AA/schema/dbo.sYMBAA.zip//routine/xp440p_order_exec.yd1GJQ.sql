


CREATE proc [dbo].[xp440p_order_exec]
@id varchar(max),
@oper_type varchar(max),
@doc_info varchar(max),
@unit_id varchar(max),
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date,
@account_num varchar(max),
@okv_number varchar(max),
@amount numeric(18,2),
@unit_bic varchar(max),
@payt_kind varchar(max),
@bi_status varchar(max),
@payer_inn varchar(max),
@payer_kpp varchar(max),
@payer_name varchar(max),
@payer_bank_name varchar(max),
@payer_bank_corr_acc varchar(max),
@payee_bank_name varchar(max),
@payee_bank_bic varchar(max),
@payee_bank_corr_acc varchar(max),
@payee_inn varchar(max),
@payee_kpp varchar(max),
@payee_name varchar(max),
@payee_acc varchar(max),
@trans_kind varchar(max),
@narrative_code varchar(max),
@piriority varchar(max),
@supplier_bill_id varchar(max),
@reserved varchar(max),
@narrative varchar(max),
@order_kinde varchar(max),
@kgn_id varchar(max),
@KBK varchar(max),
@oktmo varchar(max),
@bi_purpose varchar(max),
@bi_tax_period varchar(max),
@bi_tax_docnumber varchar(max),
@bi_tax_docdate varchar(max),
@curr_order_num varchar(max),
@curr_order_date date,
@curr_account_num varchar(max),
@div_code varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_order_exec (id,oper_type,doc_info,unit_id,  doc_key,doc_num,doc_date, account_num,okv_number,amount,unit_bic,payt_kind,bi_status,payer_inn,payer_kpp,payer_name,payer_bank_name,payer_bank_corr_acc,payee_bank_name,payee_bank_bic,payee_bank_corr_acc,payee_inn,payee_kpp,payee_name,payee_acc,trans_kind,narrative_code,piriority,supplier_bill_id,reserved,narrative,order_kinde,kgn_id,KBK,oktmo,bi_purpose,bi_tax_period,bi_tax_docnumber,bi_tax_docdate,curr_order_num,curr_order_date,curr_account_num,div_code) 
values (@id,@oper_type,@doc_info,@unit_id,  @doc_key,@doc_num,@doc_date, @account_num,@okv_number,@amount,@unit_bic,@payt_kind,@bi_status,@payer_inn,@payer_kpp,@payer_name,@payer_bank_name,@payer_bank_corr_acc,@payee_bank_name,@payee_bank_bic,@payee_bank_corr_acc,@payee_inn,@payee_kpp,@payee_name,@payee_acc,@trans_kind,@narrative_code,@piriority,@supplier_bill_id,@reserved,@narrative,@order_kinde,@kgn_id,@KBK,@oktmo,@bi_purpose,@bi_tax_period,@bi_tax_docnumber,@bi_tax_docdate,@curr_order_num,@curr_order_date,@curr_account_num,@div_code);

create table #res440
(
RESULT_CODE varchar(max),
REF varchar(max) NULL,
REJECT_CODE varchar(max) NULL,
REJECT_REASON varchar(max) NULL,
ERRORS_MESSAGE varchar(max) null
)


INSERT INTO #res440(RESULT_CODE,REF,REJECT_CODE,REJECT_REASON,ERRORS_MESSAGE) 
VALUES			   
('1',@id,null,null,null); --1 – Запрос принят к исполнению
--('2',null,null,null,null); --2 – Счет не найден
--('3',null,null,null,null); --3 – Однозначная идентификация клиента невозможна   
--('4',null,null,null,null); --4 – Клиент не найден
--('5',null,null,null,null); --5 – Счет не принадлежит клиенту
--('6',null,null,'Просто нереально исполнить',null); --6 – Наложение/снятие ограничения невозможно
--('7',@id,'4',null,null); --7 – Ограничение наложено/снято частично
--('8',null,'3',null,null); --8 – Ограничение не наложено/не снято              	
--('12',@id,null,null,null); --12 – Ограничение наложено/снято в полном объеме
--('99',null,null,null,'Обшибисча'); --99 – Ошибка выполнения 

--(null,@id,null,null,null); --без обязательного
select * from #res440;

end


go

