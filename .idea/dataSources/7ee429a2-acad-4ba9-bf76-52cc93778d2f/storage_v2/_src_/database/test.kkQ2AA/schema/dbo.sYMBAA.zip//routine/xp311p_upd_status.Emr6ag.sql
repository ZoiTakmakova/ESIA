

CREATE proc [dbo].[xp311p_upd_status]
@RECORD_ID varchar(12),
@STATUS int
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb311p_upd_status (RECORD_ID, STATUS) 
values (@RECORD_ID,@STATUS);



 return;
end


go

