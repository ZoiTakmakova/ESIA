


CREATE PROCEDURE [dbo].[fssp_get_encumbr]
@client_id varchar(40)
as
begin

create table #res7
(
ACT_DATE smalldatetime NULL,
ACCOUNT_ID varchar(40) NULL,
UNIT_BIC  varchar(20) NULL,
ENCUMBRANCE_ORG varchar(20) NULL, 
AMOUNT varchar(20) NULL,
ENC_DATE smalldatetime NULL,
ENC_PRIORITY varchar(40) NULL, 
IPNUMBER varchar(40) NULL, 
DOCNUMBER varchar(40) NULL, 
OSPCODE varchar(40) NULL, 
SPIFIO varchar(40) NULL, 
SPIPOST varchar(40) NULL, 
SPITEL varchar(40) NULL,
ENCUMBRANCE_INN varchar(40) NULL
)
insert into dbo.LAST_ID (CLIENT_ID) values (@client_id);
end

INSERT INTO #res7(ACT_DATE, ACCOUNT_ID, UNIT_BIC, ENCUMBRANCE_ORG, AMOUNT, ENC_DATE, ENC_PRIORITY, IPNUMBER, DOCNUMBER, OSPCODE, SPIFIO, SPIPOST, SPITEL, ENCUMBRANCE_INN) VALUES (GETDATE(), '40817810701000009021', '041012766', '2', '133.00', GETDATE(), '1', '123/13/12/21', '324234', '23011', 'Новр Лоак Тота', 'рор', '8-980', '9829292929'); 

select * from #res7;


go

