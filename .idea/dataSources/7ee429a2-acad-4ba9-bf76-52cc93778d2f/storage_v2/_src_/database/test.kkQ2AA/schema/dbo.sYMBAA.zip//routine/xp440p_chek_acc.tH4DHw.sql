


CREATE proc [dbo].[xp440p_chek_acc]
@id varchar(max),
@client_id varchar(max),
@doc_info varchar(max),
@unit_id varchar(max), 
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date, 
@query_type varchar(max), 
@query_kind varchar(max),
@query_from date,
@query_to date,
@query_date date,
@account_num varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_chek_acc (ID,CLIENT_ID,DOC_INFO,UNIT_ID,DOC_KEY, DOC_NUM, DOC_DATE,QUERY_TYPE,QUERY_KIND,QUERY_FROM,QUERY_TO,QUERY_DATE,account_num) 
values (@id,@client_id,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@query_type,@query_kind,@query_from,@query_to,@query_date,@account_num);

create table #res440
(
RESULT_CODE numeric(2),
ANSWER_NUM varchar(max) NULL,
ACCOUNT_NUM varchar(max) NULL,
UNIT_ID varchar(max) null,
ACCOUNT_KIND varchar(max) null,
OPEN_DATE date NULL,
CLOSED_DATE date NULL,
ACCOUNT_BALANCE numeric(20, 2) NULL,
OKV_NUMBER numeric(3) null,
RESTRICTED numeric(1) null,
ERRORS_MESSAGE varchar(max) null
)


INSERT INTO #res440(RESULT_CODE,ANSWER_NUM,ACCOUNT_NUM,UNIT_ID,ACCOUNT_KIND,OPEN_DATE,CLOSED_DATE,ACCOUNT_BALANCE,OKV_NUMBER,RESTRICTED,ERRORS_MESSAGE) 
VALUES				
--(1, '1022' ,@account_num,@unit_id,'Вид счета',GETDATE(),GETDATE(),101.10,643,0,null); -- 1 - Счет не найден
--(2, '1022' ,@account_num,@unit_id,'Вид счета',GETDATE(),GETDATE(),101.10,643,0,null); -- 2 - Счет не найден
(5, '1022' ,@account_num,@unit_id,'Вид счета',GETDATE(),GETDATE(),101.10,643,0,null); -- 2 - Счет принадлежит другому клиенту
--(99, '1022' ,null,null,null,null,null,null,null,null,'99 это ошибка'); -- 99 - Ошибка
                      	
 


 /*

 
IF @account_num = '40702978500000000786'
begin 
INSERT INTO #res440(RESULT_CODE,ANSWER_NUM,ACCOUNT_NUM,UNIT_ID,ACCOUNT_KIND,OPEN_DATE,CLOSED_DATE,ACCOUNT_BALANCE,OKV_NUMBER,RESTRICTED,ERRORS_MESSAGE) 
VALUES	
(2, '1022' ,@account_num,@unit_id,'Вид счета',GETDATE(),GETDATE(),101.10,643,0,null); -- 2 - Счет не найден
select * from #res440;
end

 
IF @account_num = '40702840900000000786'
begin 
INSERT INTO #res440(RESULT_CODE,ANSWER_NUM,ACCOUNT_NUM,UNIT_ID,ACCOUNT_KIND,OPEN_DATE,CLOSED_DATE,ACCOUNT_BALANCE,OKV_NUMBER,RESTRICTED,ERRORS_MESSAGE) 
VALUES	
(5, '1022' ,@account_num,@unit_id,'Вид счета',GETDATE(),GETDATE(),101.10,643,0,null);
select * from #res440;
end


*/





select * from #res440;

end


go

