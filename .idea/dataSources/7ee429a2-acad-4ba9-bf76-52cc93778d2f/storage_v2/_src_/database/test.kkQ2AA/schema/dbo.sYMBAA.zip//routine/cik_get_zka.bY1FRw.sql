CREATE PROCEDURE [dbo].[cik_get_zka]
@p_cl_id varchar(max),
@p_q_date date
as
begin

create table #res7
(
UNIT_ID varchar(10) NULL,
ACCOUNT_TYPE varchar(254) NULL,
ACCOUNT_NUM varchar(30) NULL,
ACCOUNT_BALANCE varchar(21) NULL,
UNIT_NAME varchar(254) NULL,
UNIT_SUBJECT varchar(2) NULL,
UNIT_ADDR_LINE1 varchar(254) NULL,
UNIT_ADDR_LINE2 varchar(254) NULL,
ACT_DATE date NULL
)

INSERT INTO #res7(UNIT_ID, ACCOUNT_TYPE, ACCOUNT_NUM, ACCOUNT_BALANCE, UNIT_NAME, UNIT_SUBJECT, UNIT_ADDR_LINE1, UNIT_ADDR_LINE2, ACT_DATE) VALUES ('901603858', 'Авва', '40817810701000009021', '239.99', 'ОАО Даем всем', '10', 'Колхоз им. Прикарманенного', 'ул.енке', GETDATE());

select * from #res7;

end
go

