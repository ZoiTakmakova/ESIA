CREATE proc [dbo].[xp440p_suspend_operations_chek]
@ref varchar(max)
as
begin
/*
insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_suspend_operations_chek (ref) 
values (@ref);
*/
create table #res440
(
RESULT_CODE varchar(max) null,
REJECT_REASON varchar(max) null,
ERROR_MESSAGE varchar(max) null
)

/*
IF @ref = '121212' --ФЛ
begin 
INSERT INTO #res440(RESULT_CODE,REJECT_REASON,ERROR_MESSAGE) 
VALUES				
('12',null,null);
select * from #res440;

end

IF @ref = '060606' --ФЛ
begin 
INSERT INTO #res440(RESULT_CODE,REJECT_REASON,ERROR_MESSAGE) 
VALUES				
('6','Опционально, если Код типа ответа = 6, 7, 8',null);
select * from #res440;
end

*/


INSERT INTO #res440(RESULT_CODE,REJECT_REASON,ERROR_MESSAGE) 

VALUES				
('12',null,null); --12 – Ограничение наложено/снято в полном объеме
--('2',null,null); --2 – Счет не найден
--('3',null,null); --3 – Однозначная идентификация клиента невозможна
--('4',null,null); --4 – Клиент не найден
--('5',null,null); --5 – Счет не принадлежит клиенту
--('6','Опционально, если Код типа ответа = 6, 7, 8',null); --6 – Наложение/снятие ограничения невозможно
--('99',null,'ERROR-99 qwe1231qew');  --99 – Ошибка выполнения         	

select * from #res440;










end


go

