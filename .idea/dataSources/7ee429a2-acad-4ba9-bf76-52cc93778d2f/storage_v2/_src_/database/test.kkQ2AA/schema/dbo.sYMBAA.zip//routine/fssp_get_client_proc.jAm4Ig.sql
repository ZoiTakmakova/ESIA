
CREATE proc [dbo].[fssp_get_client_proc]
@p_typ int,
@p_family varchar(50),
@p_father varchar(50), 
@p_first varchar(50),
@p_name varchar(150),
@p_birthday date, 
@p_birthyear date, 
@p_doc_typ varchar(50), 
@p_doc_seria varchar(50),
@p_doc_number varchar(50),
@p_inn varchar(50),
@ip_num varchar(50),
@ip_date date,
@osp_name varchar(50),
@ip_name varchar(50),
@id_subjname varchar(50),
@id_sum varchar(50),
@ip_debt varchar(50)
as
begin

insert 
/**Пишем в таблицу dbo.CLIENT_INPUT все что приходит на вход**/
into dbo.CLIENT_INPUT (DEBTOR_TYPE, DEBTOR_LAST_NAME, DEBTOR_PATRONYMIC, DEBTOR_FIRST_NAME, DEBTOR_NAME, DEBTOR_BIRTH_DATE, DEBTOR_BIRTH_YEAR, DEBTOR_DOC_TYPE_ID, DEBTOR_DOC_SER, DEBTOR_DOC_NUM, DEBTOR_INN, IP_NUM, IP_DATE, OSP_NAME, IP_NAME, ID_SUBJNAME, ID_SUM, IP_DEBT) 
values (@p_typ,@p_family,@p_father,@p_first,@p_name,@p_birthday,@p_birthyear,@p_doc_typ,@p_doc_seria,@p_doc_number,@p_inn,@ip_num,@ip_date,@osp_name,@ip_name,@id_subjname,@id_sum,@ip_debt);

/**Юридические Лица**/
IF @p_typ = 1
begin 
--insert into dbo.LAST_ID (CLIENT_ID) values ((select CLIENT_ID from dbo.client where  @p_typ = DEBTOR_TYPE and @p_inn = DEBTOR_INN and SYSTEM_ID = 'AkBars_BD'));
/**Выборка из таблицы dbo.client параметров для передачи в id-sys**/
select CLIENT_ID, SYSTEM_ID, CLIENT_FULLNAME, RESULT_CODE, ADDRESS, DEBTOR_DOC_TYPE_ID, DEBTOR_DOC_SER, DEBTOR_DOC_NUM, DEBTOR_TYPE 
from dbo.client 
where @p_typ = DEBTOR_TYPE and @p_inn = DEBTOR_INN;
end

/**Физические Лица**/
IF @p_typ = 2
begin 
--insert into dbo.LAST_ID (CLIENT_ID) values ((select CLIENT_ID from dbo.client where @p_typ = DEBTOR_TYPE and @p_family = DEBTOR_LAST_NAME and @p_birthday = DEBTOR_BIRTH_DATE and @p_doc_typ = DEBTOR_DOC_TYPE_ID and @p_doc_seria = DEBTOR_DOC_SER and @p_doc_number = DEBTOR_DOC_NUM and SYSTEM_ID = 'AkBars_BD'));
/**Выборка из таблицы dbo.client параметров для передачи в id-sys**/
select CLIENT_ID, SYSTEM_ID, CLIENT_FULLNAME, RESULT_CODE, ADDRESS, DEBTOR_DOC_TYPE_ID, DEBTOR_DOC_SER, DEBTOR_DOC_NUM, DEBTOR_TYPE 
from dbo.client 
--where @p_family = DEBTOR_LAST_NAME and @p_birthday = DEBTOR_BIRTH_DATE and @p_doc_typ = DEBTOR_DOC_TYPE_ID and @p_doc_seria = DEBTOR_DOC_SER and @p_doc_number = DEBTOR_DOC_NUM;
--where @p_typ = DEBTOR_TYPE and @p_family = DEBTOR_LAST_NAME and @p_birthday = DEBTOR_BIRTH_DATE and @p_doc_typ = DEBTOR_DOC_TYPE_ID and @p_doc_seria = DEBTOR_DOC_SER and @p_doc_number = DEBTOR_DOC_NUM;
where @p_birthday = DEBTOR_BIRTH_DATE --and @p_family = DEBTOR_LAST_NAME //@p_typ = DEBTOR_TYPE and 
end

/**Индивидуальные Предприниматели**/
IF @p_typ = 3
begin 
--insert into dbo.LAST_ID (CLIENT_ID) values ((select CLIENT_ID from dbo.client where  @p_typ = DEBTOR_TYPE and @p_inn = DEBTOR_INN and SYSTEM_ID = 'AkBars_BD'));
/**Выборка из таблицы dbo.client параметров для передачи в id-sys**/
select CLIENT_ID, SYSTEM_ID, CLIENT_FULLNAME, RESULT_CODE, ADDRESS, DEBTOR_DOC_TYPE_ID, DEBTOR_DOC_SER, DEBTOR_DOC_NUM, DEBTOR_TYPE
from dbo.client 
where @p_inn = DEBTOR_INN;
--where @p_typ = DEBTOR_TYPE and @p_inn = DEBTOR_INN;
end

end
go

