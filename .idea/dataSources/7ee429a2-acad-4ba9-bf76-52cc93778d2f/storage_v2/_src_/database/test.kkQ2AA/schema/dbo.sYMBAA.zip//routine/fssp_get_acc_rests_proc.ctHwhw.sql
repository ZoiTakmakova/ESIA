

CREATE proc [dbo].[fssp_get_acc_rests_proc]
@client_id varchar(40)
as
begin

create table #res1
(
date_actual smalldatetime NULL,
account varchar(50) NULL,
bic varchar(20) NULL,
currency varchar(3) NULL,
rest_rub numeric(20, 2) NULL,
rest_currency numeric(20, 2) NULL,
kinde_cod varchar(2) NULL,
kinde_name varchar(500) NULL
)


IF @client_id = '9016038518' 
begin
--INSERT INTO #res1 values(GETDATE(), '40820978112345678901', '123456789', '978', 514, 33973.12, '01', 'Описание');
--INSERT INTO #res1 values(GETDATE(), '42604978112345678902', '123456789', '978', 5006, 330636.12, '01', 'Описание');
--INSERT INTO #res1 values(GETDATE(), '42604978112345678903', '123456789', '978', 5006.22, 341786.12, '01', 'Описание');
INSERT INTO #res1 values(GETDATE(), '42104810112345678901', '123456789', '810', 0.00, 0.00, '01', 'Описание');
INSERT INTO #res1 values(GETDATE(), '40702978112345678902', '123456789', '840', 120.00, 1200.00, '01', 'Описание');
--INSERT INTO #res1 values(GETDATE(), '40702810112345678903', '123456789', '810', 1200.00, 1200.00, '01', 'Описание');
--INSERT INTO #res1 values(GETDATE(), '40702978112345678904', '123456789', '978', 0.00, 0.00, '01', 'Описание');
--INSERT INTO #res1 values(GETDATE(), '40702810112345678905', '123456789', '810', 0.00, 0.00, '01', 'Описание');
end

--insert into dbo.ACCOUNT_FIZ_IP (CLIENT_ID) values (@client_id);
--insert into #res values(GETDATE(), '40819810112345678901', '123456789', '643', 1.00, 1.00);
--insert into #res values(GETDATE(), '40819810112345678902', '123456789', '643', 2.00, 2.00);
--insert into #res values(GETDATE(), '40819810112345678903', '123456789', '643', 3.00, 3.00);
 
select * from #res1;

end


go

