
CREATE proc [dbo].[xp440p_stop_suspend_operations_chek]
@ref varchar(max)
as
begin
/*
insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_stop_suspend_operations_chek (ref) 
values (@ref);
*/
create table #res440
(
RESULT_CODE varchar(max) null,
REJECT_REASON varchar(max) null,
ERROR_MESSAGE varchar(max) null
)


/*
INSERT INTO #res440(RESULT_CODE,REJECT_REASON,ERROR_MESSAGE) 

VALUES				('12','12345',null);
--VALUES				('6',null,'REJECT_REASON, Опционально, если Код типа ответа = 6',null);
--VALUES				('99',null,null,'ERROR_MESSAGE, Обязательно, если Код результата операции  = 99'); 

--VALUES				('1','12345',null,null);
--VALUES				('2',null,null,null);
--VALUES				('3',null,null,null);
--VALUES				('4',null,null,null);
--VALUES				('5',null,null,null);
--VALUES				('6','код 6, ну допустим, что счет у нас закрыт',null);
select * from #res440;
*/



IF @ref = '121212' --	12 – Ограничение наложено/снято в полном объеме
begin 
INSERT INTO #res440(RESULT_CODE,REJECT_REASON,ERROR_MESSAGE) 
VALUES					('12','12345',null);
select * from #res440;
end

IF @ref = '060606' --	6 – Наложение/снятие ограничения невозможно
begin 
INSERT INTO #res440(RESULT_CODE,REJECT_REASON,ERROR_MESSAGE) 
VALUES				('6','код 6 ну допустим счет закрыт',null);
select * from #res440;
end


end


go

