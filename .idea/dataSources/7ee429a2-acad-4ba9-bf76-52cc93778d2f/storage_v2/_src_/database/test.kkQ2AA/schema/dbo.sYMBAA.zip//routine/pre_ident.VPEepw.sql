



CREATE proc [dbo].[pre_ident]
@p_typ int,
@p_family varchar(50),
@p_father varchar(50), 
@p_first varchar(50),
@p_name varchar(50),
@p_birthday date, 
@p_birthyear date, 
@p_doc_typ varchar(50), 
@p_doc_seria varchar(50),
@p_doc_number varchar(50),
@p_inn varchar(50)
as
begin

create table #res1
(
id varchar(40)
)

IF @p_typ = 1 
begin
INSERT INTO #res1(id) VALUES ('2');
end
IF @p_typ = 2 
begin 
insert into dbo.ACCOUNT_FIZ_IP (ACCOUNT_TYPE,LAST_NAME,PATRONYMIC_NAME,FIRST_NAME,ADDITIONAL_FIELD_1,BIRTH_DATE,OKV_NUMBER,DOC_TYPE_ID,DOC_SER,DOC_NUM,INN) values (@p_typ,@p_family,@p_father,@p_first,@p_name,@p_birthday,@p_birthyear,@p_doc_typ,@p_doc_seria,@p_doc_number,@p_inn);
INSERT INTO #res1(id) VALUES ('0'); 
end  
      
IF @p_typ = 3 
begin 
INSERT INTO #res1(id) VALUES ('1'); 
end                        	
 
select * from #res1;

end

--'21, 92 03, 798933 (РМК, WAY4)'


go

