
CREATE proc [dbo].[xp390p_identify]
@id varchar(max),
@doc_info varchar(max),
@unit_id varchar(max),
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date,
@client_type varchar(max),
@last_name varchar(max),
@first_name varchar(max),
@patronymic_name varchar(max),
@name varchar(max),
@inn varchar(max),
@kpp varchar(max),
@postal_code varchar(max),
@region_code varchar(max),
@district varchar(max),
@city varchar(max),
@locality varchar(max),
@street varchar(max),
@house varchar(max),
@building varchar(max),
@apartment varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb390p_identify (ID,DOC_INFO,UNIT_ID,DOC_KEY,DOC_NUM,DOC_DATE,CLIENT_TYPE,LAST_NAME,FIRST_NAME,PATRONYMIC_NAME,NAME,INN,KPP,POSTAL_CODE,REGION_CODE,DISTRICT,CITY,LOCALITY,STREET,HOUSE,BUILDING,APARTMENT) 
values (@id,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@client_type,@last_name,@first_name,@patronymic_name,@name,@inn,@kpp,@postal_code,@region_code,@district,@city,@locality,@street,@house,@building,@apartment);

create table #res390
(
RESULT_CODE varchar(max) NULL,
CLIENT_ID varchar(max) NULL,
SYSTEM_ID varchar(max) NULL,
NAME varchar(max) NULL,
INN varchar(max) NULL,
KPP varchar(max) NULL,
LAST_NAME varchar(max) NULL,
FIRST_NAME varchar(max) NULL,
PATRONYMIC_NAME varchar(max) NULL,
ERROR_MESSAGE varchar(max) NULL

)



IF @client_type = '2' --ФЛ
begin 
INSERT INTO #res390 (RESULT_CODE, CLIENT_ID, SYSTEM_ID, NAME, INN, KPP, LAST_NAME, FIRST_NAME, PATRONYMIC_NAME, ERROR_MESSAGE) 
VALUES	
 ('1',@id,'390P',null,@inn,null,@last_name,@first_name,@patronymic_name,null);
 --('4',@id,'390P',null,@inn,null,@last_name,@first_name,@patronymic_name,null);	
 --('3',@id,'390P',null,@inn,null,@last_name,@first_name,@patronymic_name,null);	
 -- ('99',@id,'390P',null,@inn,null,@last_name,@first_name,@patronymic_name,'99 error');	



IF @client_type = '1' --ЮЛ
begin 
INSERT INTO #res390 (RESULT_CODE, CLIENT_ID, SYSTEM_ID, NAME, INN, KPP, LAST_NAME, FIRST_NAME, PATRONYMIC_NAME, ERROR_MESSAGE) 
VALUES	
 --('1',@id,'390P',@name,@inn,@kpp,null,null,null,null);
('4',@id,'390P',@name,@inn,@kpp,null,null,null,null);	
-- ('3',@id,'390P',@name,@inn,@kpp,null,null,null,null);	
--('99',@id,'390P',null,null,null,null,null,null,'ERROR_MESSAGE');		
select * from #res390;
end



select * from #res390;
end



end

go

