CREATE PROCEDURE [dbo].[cik_get_zk]
@FAMILY_NAME varchar(max), 
@FIRST_NAME varchar(max),
@PATRONYMIC varchar(max),
@DATE_BIRTH date,
@DOC_TYP varchar(max), 
@DOC_SERIA varchar(max),
@DOC_NUMBER varchar(max)
as
begin

create table #res7
(
CLIENT_ID varchar(40)
)

insert into dbo.CIK_ZK (FAMILY_NAME, FIRST_NAME, PATRONYMIC, DATE_BIRTH, DOC_TYP, DOC_SERIA, DOC_NUMBER) values (@FAMILY_NAME, @FIRST_NAME, @PATRONYMIC, @DATE_BIRTH, @DOC_TYP, @DOC_SERIA, @DOC_NUMBER);

INSERT INTO #res7(CLIENT_ID) VALUES ('9016038518');

select * from #res7;

end
go

