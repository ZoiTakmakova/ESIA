



CREATE proc [dbo].[xp440p_suspend_operations]
@id varchar(max),
@oper_type varchar(max),
@doc_info varchar(max),
@unit_id varchar(max),  
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date varchar(max),
@account_num varchar(max),
@okv_number varchar(max),
@unit_bic varchar(max),
@amount varchar(max),
@div_code  varchar(max),
@div_name  varchar(max),
@reason_code  varchar(max),
@reason_details  varchar(max),
@prim_doc_num  varchar(max),
@prim_doc_date  varchar(max),
@sender_phone  varchar(max),
@sender_name  varchar(max),
@sender_post  varchar(max)


as
begin
/*
insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_suspend_operations(id,oper_type,doc_info,unit_id,doc_key,doc_num,doc_date,account_num,okv_number,unit_bic,amount) 
values (@id,@oper_type,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@account_num,@okv_number,@unit_bic,@amount);
*/
create table #res440
(
RESULT_CODE varchar(max) NULL,
REF varchar(max) NULL,
REJECT_REASON varchar(max) NULL,
ERRORS_MESSAGE varchar(max) null
)


IF @account_num = '40702810600000000786' --ФЛ
begin 
INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERRORS_MESSAGE) 
VALUES				
--('1','060606',null,null);
('12','1060606',null,'Ограничение наложено/снято в полном объеме');
select * from #res440;
end


IF @account_num = '40702978500000000786' --ФЛ
begin 
INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERRORS_MESSAGE) 
VALUES				
('12','1060606',null,null);
--('1','060606',null,null);
select * from #res440;
end

IF @account_num = '40702840900000000786' --ФЛ
begin 
INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERRORS_MESSAGE) 
VALUES				
('6','1060606','Невозможно исполнить, смотрим сюда{VOTSUDA}сюда счёт №40702203900005000438 не попадает под понятие счета, указанного в п.2 ст.11 НК РФ','Наложение/снятие ограничения невозможно');
--('1','121212',null,null);
select * from #res440;
end


/*
INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERRORS_MESSAGE) 
VALUES				
('1',cast((rand()*999999)as varchar(max)),null,null); --1 – Запрос принят к исполнению
--('2',null,null,null); --2 – Счет не найден
--('3',null,null,null); --3 – Однозначная идентификация клиента невозможна     
--('4',null,null,null); --4 – Клиент не найден
--('5',null,null,null); --5 – Счет не принадлежит клиенту
--('6',null,'ПРичина вв',null); --6 – Наложение/снятие ограничения невозможно
--('12',cast((rand()*999999)as varchar(max)),null,null); --12 – Ограничение наложено/снято в полном объеме
--('12',null,null,null);\\error
--('99',null,null,'Снова ошибка'); --99 – Ошибка выполнения 

 */
select * from #res440;

end


go

