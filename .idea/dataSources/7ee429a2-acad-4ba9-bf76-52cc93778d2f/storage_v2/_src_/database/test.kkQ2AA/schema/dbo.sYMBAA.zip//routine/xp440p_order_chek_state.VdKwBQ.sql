


CREATE proc [dbo].[xp440p_order_chek_state]
@id varchar(max),
@doc_info varchar(max),
@unit_id varchar(max),  
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date, 
@account_num numeric(20),
@ref varchar(max)

as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_order_chek_state (id,doc_info,unit_id,doc_key,doc_num,doc_date,account_num,ref) 
values (@id,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@account_num,@ref);

create table #res440
(
RESULT_CODE numeric(2),
AMOUNT numeric(20,2) NULL,
ERRORS_MESSAGE varchar(max) null
)


INSERT INTO #res440(RESULT_CODE,AMOUNT,ERRORS_MESSAGE) 
VALUES				(14,110.00,null);
                      	
 
select * from #res440;

end


go

