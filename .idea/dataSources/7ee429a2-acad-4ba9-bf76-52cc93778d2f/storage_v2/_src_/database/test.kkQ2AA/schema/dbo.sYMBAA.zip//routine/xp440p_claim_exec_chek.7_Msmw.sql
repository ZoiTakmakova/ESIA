




CREATE proc [dbo].[xp440p_claim_exec_chek]
@ref varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_claim_exec_chek (ref) 
values (@ref);

create table #res440
(
RESULT_CODE varchar(max) null,
REJECT_REASON varchar(max) null,
ERROR_MESSAGE varchar(max) null
)


INSERT INTO #res440(RESULT_CODE,REJECT_REASON,ERROR_MESSAGE) 

VALUES					('12',null,null);
--VALUES				('6','REJECT_REASON, Опционально, если Код типа ответа = 6',null);
--VALUES				('99',null,'ERROR_MESSAGE, Обязательно, если Код результата операции  = 99'); 

--VALUES				('2',null,null);
--VALUES				('3',null,null);
--VALUES				('4',null,null);
--VALUES				('5',null,null);
--VALUES				('6',null,null);
         	
 
select * from #res440;

end


go

