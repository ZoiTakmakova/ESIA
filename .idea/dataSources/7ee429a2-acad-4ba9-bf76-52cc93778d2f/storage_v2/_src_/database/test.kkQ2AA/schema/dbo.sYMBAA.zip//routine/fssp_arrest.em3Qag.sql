



CREATE proc [dbo].[fssp_arrest]
@acc_id varchar(40),
@unit_bic varchar(40),
@amount numeric(20, 2),
@okv_num numeric(10),
@OSP_CODE varchar(40),
@DOC_DATE date,
@SPI_FIO varchar(40),
@NARRATIVE varchar(40),
@REF varchar(40)
as


begin
/**Добавление записей о наложенном аресте в таблицу dbo.ENCUMBRANCE для последующего использования при в обработке документов по данному клиенту**/
--insert into dbo.ENCUMBRANCE (CLIENT_ID,ACT_DATE,ACCOUNT_ID,UNIT_BIC,AMOUNT,ENCUMBRANCE_DATE,ENCUMBRANCE_ID) values ((select CLIENT_ID from dbo.ACCOUNT where ACCOUNT_ID = @acc_id),GETDATE(),@acc_id,@unit_bic,(@amount/((select account_balance_eq from dbo.ACCOUNT where account_id = @acc_id)/(select account_balance from dbo.ACCOUNT where account_id = @acc_id))),GETDATE(),(90000 + rand()*999999));
/**Добавление записей попавших на вход сведений в таблицу dbo.ARREST_INPUT с целью логгирования**/
insert into dbo.ARREST_INPUT(ACCOUNT_ID,UNIT_BIC,AMOUNT,OKV_NUMBER,OSP_CODE,DOC_DATE,SPI_FIO,NARRATIVE,REF) values (@acc_id, @unit_bic, @amount, @okv_num, @OSP_CODE, @DOC_DATE, @SPI_FIO, @NARRATIVE, @REF);

/**Создание виртуальной таблицы**/
create table #res4
(
ref varchar(100) NULL,
result_code decimal(5, 0),
narrative varchar(50) NULL
)
/**Вставка в виртуальную таблицу данных**/
insert into #res4 values(cast((rand()*999999)as varchar(max)),1,'Наложение ареста');
/**Выборка из виртуальной таблицы данных для передачи в Систему**/
select * from #res4;
end
go

