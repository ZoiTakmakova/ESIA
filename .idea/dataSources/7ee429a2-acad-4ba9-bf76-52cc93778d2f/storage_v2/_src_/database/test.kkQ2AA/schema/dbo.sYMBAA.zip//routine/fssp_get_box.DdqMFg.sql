

CREATE PROCEDURE [dbo].[fssp_get_box]
@client_id varchar(40)
as
begin

create table #res7
(
ACT_DATE smalldatetime NULL,
CONTRACT_NUMBER varchar(40) NULL,
CONTRACT_DATE  smalldatetime NULL,
BRANCH_NAME varchar(20) NULL, 
BRANCH_ADDRESS varchar(20) NULL
)
insert into dbo.LAST_ID (CLIENT_ID) values (@client_id);
end
INSERT INTO #res7(ACT_DATE, CONTRACT_NUMBER, CONTRACT_DATE, BRANCH_NAME, BRANCH_ADDRESS) VALUES (GETDATE(), '08948034', GETDATE(), 'БранчИмяяя', 'Бранчадресссс'); 

select * from #res7;

go

