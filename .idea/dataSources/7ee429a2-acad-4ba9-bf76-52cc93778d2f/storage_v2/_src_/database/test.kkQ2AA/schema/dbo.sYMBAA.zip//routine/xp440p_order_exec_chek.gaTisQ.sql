



CREATE proc [dbo].[xp440p_order_exec_chek]
@ref varchar(max)
as
begin
/**
insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_order_exec_chek (ref) 
values (@ref);
**/
create table #res440
(
RESULT_CODE varchar(max) null,
REF varchar(max) null,
AMOUNT numeric(18,2) null,
REJECT_CODE varchar(max) null,
REJECT_REASON varchar(max) null,
ERROR_MESSAGE varchar(max) null
)

INSERT INTO #res440(RESULT_CODE,REF,AMOUNT,REJECT_CODE,REJECT_REASON,ERROR_MESSAGE) 
--VALUES				('12',@ref,null,null,null,null); --12 – Ограничение наложено/снято в полном объеме
--VALUES				('2',null,null,null,null,null); --2 – Счет не найден
--VALUES				('3',null,null,null,null,null);	--3 – Однозначная идентификация клиента невозможна
--VALUES				('4',null,null,null,null,null); --4 – Клиент не найден
--VALUES				('5',null,null,null,null,null); --5 – Счет не принадлежит клиенту
--VALUES				('6',null,null,null,'Невозможно исполнить документ налогового органа. Опционально, если Код типа ответа = 6, 7, 8',null); --6 – Наложение/снятие ограничения невозможно
--VALUES				('7',@ref,1250.00,'1',null,null); --частич
--VALUES				('7',@ref,'1000','1','Опционально, если Код типа ответа = 6, 7, 8',null); --7 – Ограничение наложено/снято частично
VALUES				('8',null,null,'2','Опционально, если Код типа ответа = 6, 7, 8',null);	 --8 – Ограничение не наложено/не снято		
--VALUES				('99',null,null,null,null,'ERROR-99 qwe1231qew');  --99 – Ошибка выполнения 


--VALUES				('3',null,null,null,null,null);
--VALUES				('5',null,null,null,null,null);
--VALUES				('6',null,null,null,'Опционально, если Код типа ответа = 6, 7, 8',null);
  --VALUES				('',null,null,null,null,null);
  --VALUES				('',null,null,null,null,null);
--VALUES				('12','2',null,null,null,null);                      	
 
select * from #res440;
end


go

