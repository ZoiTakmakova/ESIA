
CREATE proc [dbo].[xp440p_stop_suspend_operations]
@id varchar(max),
@oper_type varchar(max),
@doc_info varchar(max),
@unit_id varchar(max),  
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date varchar(max),
@src_doc_num varchar(max),
@src_doc_date varchar(max),
@account_num varchar(max),
@unit_bic varchar(max),
@ref varchar(max),
@prim_doc_num varchar(max),
@prim_doc_date varchar(max),
@decision_kind varchar(max)
as
begin
/*
insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_stop_suspend_operations(id,oper_type,doc_info,unit_id,doc_key,doc_num,doc_date,src_doc_num,src_doc_date,account_num,unit_bic,ref) 
values (@id,@oper_type,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@src_doc_num,@src_doc_date,@account_num,@unit_bic,@ref);
*/
create table #res440
(
RESULT_CODE varchar(max),
REF varchar(max) NULL,
REJECT_REASON varchar(max) NULL,
ERROR_MESSAGE varchar(max) NULL
)

/*
INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERROR_MESSAGE) 
VALUES				
('1','12345',null,null); --1 – Запрос принят к исполнению
--('1',cast((rand()*999999)as varchar(max)),null,null); --1 – Запрос принят к исполнению
--('2',null,null,null); --2 – Счет не найден
--('3',null,null,null); --3 – Однозначная идентификация клиента невозможна     
--('4',null,null,null); --4 – Клиент не найден
--('5',null,null,null); --5 – Счет не принадлежит клиенту
--('6',null,'ПРичина вв',null); --6 – Наложение/снятие ограничения невозможно
--('12',cast((rand()*999999)as varchar(max)),null,null); --12 – Ограничение наложено/снято в полном объеме
--('99',null,null,'Снова ошибка'); --99 – Ошибка выполнения 
select * from #res440;
*/

IF @account_num = '40702810600000000786' 
begin 
INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERROR_MESSAGE) 
VALUES				
('1','121212',null,null); --1 – Запрос принят к исполнению
select * from #res440;
end

IF @account_num = '40702978500000000786' 
begin 
INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERROR_MESSAGE) 
VALUES				
('1','060606',null,null); --1 – Запрос принят к исполнению
select * from #res440;
end


end


go

