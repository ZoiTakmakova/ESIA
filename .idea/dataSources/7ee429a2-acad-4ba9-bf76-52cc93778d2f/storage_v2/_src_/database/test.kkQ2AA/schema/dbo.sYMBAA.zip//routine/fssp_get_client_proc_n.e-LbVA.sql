CREATE PROCEDURE [dbo].[fssp_get_client_proc_n]
@p_typ varchar(max),
@p_family varchar(max),
@p_father varchar(max), 
@p_first varchar(max),
@p_name varchar(max),
@p_birthday date, 
@p_birthyear date, 
@p_doc_typ varchar(max), 
@p_doc_seria varchar(max),
@p_doc_number varchar(max),
@p_inn varchar(max),
@addr_1 varchar(max),
@addr_2 varchar(max),
@DEBTOR_DOC_TYPE_ID_SPDUL varchar(max)
as
begin

create table #res7
(
CLIENT_ID varchar(40),
CLIENT_FULLNAME varchar(1000) NULL,
CUSTOMER_CATEGORY varchar(1000) NULL,
CUSTOMER_CATEGORY_2 varchar(1000) NULL,
RECORDS_COUNT varchar(1000) NULL
)

--IF @p_typ = 1 
--begin
--insert into dbo.ACCOUNT_FIZ_IP (ACCOUNT_TYPE,LAST_NAME,PATRONYMIC_NAME,FIRST_NAME,ADDITIONAL_FIELD_1,ACCOUNT_BALANCE,OKV_NUMBER,DOC_TYPE_ID,DOC_SER,DOC_NUM,ADDRESS,CLIENT_BIRTHPLACE,ENCUMBRANCE_ORG,DOC_VIDAN) values (@p_typ,@p_family,@p_father,@p_first,@p_name,@p_birthday,@p_birthyear,@p_doc_typ,@p_doc_seria,@p_doc_number,@p_inn,@addr_1,@addr_2,@DEBTOR_DOC_TYPE_ID_SPDUL);
--declare @i bigint;
--set @i = 1000000000000;
--WAITFOR DELAY '00:00:01';
 -- while @i<=1
 -- begin
  --set @i=@i+1;
--end
INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2, RECORDS_COUNT) VALUES ('9016038518', @p_name,'vip6','ultravip2',1);
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2, RECORDS_COUNT) VALUES ('9016038513', @p_name,'vip2','ultravip1',2);
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2, RECORDS_COUNT) VALUES ('999999999', @p_name,'vip3','ultravip1',2);
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2, RECORDS_COUNT) VALUES (NULL,NULL,NULL,NULL,NULL);
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2) VALUES ('10000e', 'ООО Рога и Копыта');
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2) VALUES ('10222200r', 'ООО Рога и Копыта');
--end
--IF @p_typ = 2 
--begin 
--insert into dbo.ACCOUNT_FIZ_IP (ACCOUNT_TYPE,LAST_NAME,PATRONYMIC_NAME,FIRST_NAME,ADDITIONAL_FIELD_1,BIRTH_DATE,OKV_NUMBER,DOC_TYPE_ID,DOC_SER,DOC_NUM,INN) values (@p_typ,@p_family,@p_father,@p_first,@p_name,@p_birthday,@p_birthyear,@p_doc_typ,@p_doc_seria,@p_doc_number,@p_inn);
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2,RECORDS_COUNT) VALUES ('9016038516', @p_name,'vip5','ultravip1',1); 
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2,RECORDS_COUNT) VALUES ('9016038518', @p_name,'vip3','ultravip1',2); 
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2,RECORDS_COUNT) VALUES ('9016038519', @p_name,'vip3','ultravip1',2); 
--INSERT INTO #res7(id, fullname, CLIENT_FULLNAME, RESULT_CODE) VALUES ('9016038517', 'TESTSYS02', 'Клиент Фулл Найм', 2); 
--INSERT INTO #res1(id, fullname) VALUES ('9016038516', 'ГРЕБНЕВ АЛЕКСАНДР ДАНИЛОВИЧ, 25.07.1944'); 
--INSERT INTO #res1(id, fullname) VALUES ('9016038517', 'ГРЕБНЕВ АЛЕКСАНДР ДАНИЛОВИЧ, 25.07.1944'); 
--end  
      
--IF @p_typ = 3 
--begin 

--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2, RECORDS_COUNT) VALUES ('9016038513', @p_name,'vip2','ultravip1',2);
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2, RECORDS_COUNT) VALUES ('9016038514', @p_name,'vip2','ultravip1',2);
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2) VALUES ('300001', @p_name,'vip1','ultravip1'); 
--INSERT INTO #res7(CLIENT_ID, CLIENT_FULLNAME, CUSTOMER_CATEGORY, CUSTOMER_CATEGORY_2) VALUES ('300003', 'ИП ЛЕРМОНТОВ ЮРИЙ ИВАНОВИЧ'); 
--end                        	
 
select * from #res7;

end
go

