


CREATE proc [dbo].[fssp_get_acc_enc]
@client_id varchar(40)
as
begin

create table #res2
(
date_actual smalldatetime NULL,
account varchar(50) NULL,
bic varchar(20) NULL,
enc_org varchar(40) NULL,
amount numeric(20, 2) NULL,
date_1 smalldatetime NULL
)

insert into #res2 values(GETDATE(), '40809810112345678901', '123456789', 1, 100.00, '2006-04-25');
insert into #res2 values(GETDATE(), '40809810112345678902', '123456789', 1, 200.00, '2006-04-25');
insert into #res2 values(GETDATE(), '40809810112345678903', '123456789', 1, 300.00, '2006-04-25');
 
select * from #res2;

end


go

