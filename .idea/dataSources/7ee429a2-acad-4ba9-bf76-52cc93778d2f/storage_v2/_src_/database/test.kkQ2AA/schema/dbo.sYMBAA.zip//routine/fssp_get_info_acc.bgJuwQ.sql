



CREATE proc [dbo].[fssp_get_info_acc]
@client_id varchar(40)
as
begin
insert into dbo.LAST_ID (CLIENT_ID) values (@client_id);
/**Выборка сведений о счетах клиента из таблицы dbo.ACCOUNT данных для передачи в id-sys**/
select ACT_DATE,ACCOUNT_ID,UNIT_BIC,OKV_NUMBER,ACCOUNT_BALANCE,ACCOUNT_BALANCE_EQ,ACCOUNT_ARCHIVE,ACCOUNT_CATEGORY,ACCOUNT_KIND from dbo.ACCOUNT where CLIENT_ID = @client_id;
end

/**
create table #res2
(
date_actual smalldatetime NULL,
account varchar(50) NULL,
bic varchar(20) NULL,
enc_org varchar(40) NULL,
amount numeric(20, 2) NULL,
amount_eq numeric(20, 2) NULL,
arch numeric(3) NULL,
category varchar(40) NULL
)
insert into dbo.ACCOUNT_FIZ_IP (CLIENT_ID, LAST_NAME) values (@client_id, 'Poisk sved o schetah');
insert into #res2 values(GETDATE(), '40817810701000008021', '041012765', '810', 410, 410, 0, 557);
insert into #res2 values(GETDATE(), '40817978701000009001', '041012765', '978', 12, 120, 0, 338);
insert into #res2 values(GETDATE(), '40817810701000006022', '041012765', '810', 120, 120, 0, '');
--Приоритет счетов
--insert into #res2 values(GETDATE(), '42302810701000001026', '999999999', '643', 200.00, 200.00, 0);
--insert into #res2 values(GETDATE(), '42305810701000001026', '999999999', '643', 300.00, 300.00, 0);
--insert into #res2 values(GETDATE(), '42301810701000001026', '999999999', '643', 100.00, 100.00, 0);
--insert into #res2 values(GETDATE(), '42303810701000001026', '999999999', '643', 200.00, 200.00, 0);
select * from #res2;
**/

go

