



CREATE proc [dbo].[fssp_chek_acc]
@acc_id varchar(40),
@unit_bic varchar(40)
as
begin
/**Создание виртуальной таблицы**/ 
create table #res3
(
add_3 varchar(50) NULL,
status_code decimal(5, 0) NULL,
add_1 varchar(50) NULL,
add_2 varchar(50) NULL
)

/**Блок отбора сведений для передачи в Систему**/
if @acc_id = (select ACCOUNT_ID from dbo.chek where ACCOUNT_ID = @acc_id and UNIT_BIC = @unit_bic)
begin
select ADDITIONAL_FIELD,STATUS_CODE,ADDITIONAL_FIELD,ADDITIONAL_FIELD from dbo.CHEK where ACCOUNT_ID = @acc_id and UNIT_BIC = @unit_bic;
end
else
begin
insert into #res3 values('Доп поле',1,'Еще поле','Тоже поле');
select * from #res3;
end
end


go

