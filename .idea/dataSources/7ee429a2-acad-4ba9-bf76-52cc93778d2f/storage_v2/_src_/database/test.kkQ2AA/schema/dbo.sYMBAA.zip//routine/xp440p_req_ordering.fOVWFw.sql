


CREATE proc [dbo].[xp440p_req_ordering]
@id varchar(max),
@doc_info varchar(max), 
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date, 
@query_type varchar(max), 
@query_kind varchar(max),
@query_from date,
@query_to date,
@account_num varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_req_ordering (ID,DOC_INFO,DOC_KEY, DOC_NUM, DOC_DATE,QUERY_TYPE,QUERY_KIND,QUERY_FROM,QUERY_TO,account_num) 
values (@id,@doc_info,@doc_key,@doc_num,@doc_date,@query_type,@query_kind,@query_from,@query_to,@account_num);

create table #res440
(
RESULT_CODE varchar(max),
REF varchar(max) NULL,
ANSWER_NUM varchar(max) NULL,
ERRORS_MESSAGE varchar(max) null
)


INSERT INTO #res440(RESULT_CODE,REF,ANSWER_NUM,ERRORS_MESSAGE) 
VALUES				('1', cast((rand()*999999)as varchar(max)) ,cast((rand()*999999)as varchar(max)),null);
--VALUES				('2',null,null,null);
                      	
 
select * from #res440;

end


go

