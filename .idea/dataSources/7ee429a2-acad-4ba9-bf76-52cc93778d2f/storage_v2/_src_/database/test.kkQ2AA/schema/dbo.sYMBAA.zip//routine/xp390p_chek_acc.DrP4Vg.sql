

CREATE proc [dbo].[xp390p_chek_acc]

@id varchar(max),
@client_id varchar(max),
@doc_info varchar(max),
@unit_id varchar(max),
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date,
@account_num varchar(max)

as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb390p_chek_acc (ID,CLIENT_ID,DOC_INFO,UNIT_ID,DOC_KEY,DOC_NUM,DOC_DATE,ACCOUNT_NUM) 
values (@id,@client_id,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@account_num);


create table #res390
(
RESULT_CODE varchar(max) NULL,
ACCOUNT_NUM varchar(max) NULL,
UNIT_ID varchar(max) NULL,
ACCOUNT_KIND varchar(max) NULL,
OKV_NUMBER varchar(max) NULL,
ERROR_MESSAGE varchar(max) NULL
)

begin 
INSERT INTO #res390 (RESULT_CODE,ACCOUNT_NUM,UNIT_ID,ACCOUNT_KIND,OKV_NUMBER,ERROR_MESSAGE) 
VALUES	
--('5','40702810600000000786',@unit_id,'Вид счета','810','ERROR_MESSAGE');	
('2','40702810600000000786',@unit_id,'Вид счета','810','ERROR_MESSAGE');	
--('99','40702810600000000786',@unit_id,'Вид счета','810','ERROR_MESSAGE');	
--('RESULT_CODE','40702810600000000786',@unit_id,'Вид счета','810','ERROR_MESSAGE');	
select * from #res390;
end

end


go

