
CREATE PROCEDURE [dbo].[fssp_get_depo]
@client_id varchar(40)
as
begin

create table #res7
(
ACT_DATE smalldatetime NULL,
STR_ACC varchar(40) NULL,
DEPT_CODE  varchar(40) NULL,
UNIT_BIC varchar(20) NULL 
)
insert into dbo.LAST_ID (CLIENT_ID) values (@client_id);
end
INSERT INTO #res7(ACT_DATE, STR_ACC, DEPT_CODE, UNIT_BIC) VALUES (GETDATE(), '123456789', '001', '100056789'); 

select * from #res7;
go

