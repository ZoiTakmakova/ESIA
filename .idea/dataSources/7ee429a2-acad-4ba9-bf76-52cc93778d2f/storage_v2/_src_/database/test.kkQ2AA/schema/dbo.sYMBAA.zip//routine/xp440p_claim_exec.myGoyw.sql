



CREATE proc [dbo].[xp440p_claim_exec]
@id varchar(max),
@oper_type varchar(max),
@doc_info varchar(max),
@unit_id varchar(max),
@doc_key varchar(max),
@doc_num varchar(max),
@doc_date date,
@account_num varchar(max),
@unit_bic varchar(max),
@amount varchar(max)
as
begin

insert 
/**Пишем в таблицу  все что приходит на вход**/
into tb440p_claim_exec(id,oper_type,doc_info,unit_id,doc_key,doc_num,doc_date,account_num,unit_bic,amount) 
values (@id,@oper_type,@doc_info,@unit_id,@doc_key,@doc_num,@doc_date,@account_num,@unit_bic,@amount);

create table #res440
(
RESULT_CODE varchar(max) NULL,
REF varchar(max) NULL,
REJECT_REASON varchar(max) NULL,
ERRORS_MESSAGE varchar(max) null
)


INSERT INTO #res440(RESULT_CODE,REF,REJECT_REASON,ERRORS_MESSAGE) 
VALUES				
('1',cast((rand()*999999)as varchar(max)),null,null); --1 – Запрос принят к исполнению
--('2',null,null,null); --2 – Счет не найден
--('3',null,null,null); --3 – Однозначная идентификация клиента невозможна     
--('4',null,null,null); --4 – Клиент не найден
--('5',null,null,null); --5 – Счет не принадлежит клиенту
--('6',null,'ПРичина вв',null); --6 – Наложение/снятие ограничения невозможно
--('12',cast((rand()*999999)as varchar(max)),null,null); --12 – Ограничение наложено/снято в полном объеме
--('99',null,null,'Снова ошибка'); --99 – Ошибка выполнения 
                      	
 
select * from #res440;

end


go

